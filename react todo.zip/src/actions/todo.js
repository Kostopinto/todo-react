import {
  ADD_TASK,
  DELETE_TASK,
  EDIT_TASK,
  COMPLETED_TASK,
  SAVE_EDIT_TASK,
  LOGIN,
  ADD_TOKEN,
  GET_ALL_TODOS,
  GET_TODOS_BACK
} from "./actionTypes";

export const addTask = newTodoValue => ({
  type: ADD_TASK,
  payload: newTodoValue
});

export const deleteTask = index => ({ type: DELETE_TASK, payload: index });

export const editTask = index => ({ type: EDIT_TASK, payload: index });

export const completedTask = index => ({
  type: COMPLETED_TASK,
  payload: index
});

export const saveEditTask = (editValue, index) => ({
  type: SAVE_EDIT_TASK,
  payload: {
    editValue,
    index
  }
});

export const login = (login, password) => ({
  type: LOGIN,
  payload: {
    login,
    password
  }
});

export const addToken = token => ({
  type: ADD_TOKEN,
  payload: token
});

export const getAllTodos = () => ({
  type: GET_ALL_TODOS
});

export const getTodosBack = res => ({
  type: GET_TODOS_BACK,
  payload: res
});

export function loginUser(payload) {
  console.log("local", localStorage);
  return dispatch => {
    return fetch(`http://localhost:3000/login`, {
      headers: {
        "Content-Type": "application/json"
      },
      method: "POST",
      body: JSON.stringify({
        login: payload.inputValueLogin,
        password: payload.inputValuePass
      })
    })
      .then(res => res.json())
      .then(res =>
        res.status === 200
          ? localStorage.setItem("token", res.token)
          : console.log("error", res.status)
      );
  };
}

export function getAll() {
  return dispatch => {
    return fetch(`http://localhost:3000/todos/all`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`
      },
      method: "GET"
    })
      .then(res => res.json())
      .then(res => getTodosBack(res));
  };
}
