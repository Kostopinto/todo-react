export const ADD_TASK = "ADD_TASK";
export const DELETE_TASK = "DELETE_TASK";
export const EDIT_TASK = "EDIT_TASK";
export const SAVE_EDIT_TASK = "SAVE_EDIT_TASK";
export const COMPLETED_TASK = "COMPLETED_TASK";

export const LOGIN = "LOGIN";
export const ADD_TOKEN = "ADD_TOKEN";

export const GET_ALL_TODOS = "GET_ALL_TODOS";
export const GET_TODOS_BACK = "GET_TODOS_BACK";
