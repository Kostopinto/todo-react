import {
  ADD_TASK,
  DELETE_TASK,
  EDIT_TASK,
  COMPLETED_TASK,
  SAVE_EDIT_TASK,
  LOGIN,
  ADD_TOKEN,
  GET_TODOS_BACK
} from "../actions/actionTypes";

const initialState = {
  todos: [
    {
      description: "kotelvaaaa",
      isEditing: false,
      isChecked: false
    }
  ],
  token: []
};

export default (state = initialState, action) => {
  switch (action.type) {
    case ADD_TASK:
      console.log("state token", state.token);
      const newTODO = {
        description: action.payload,
        isEditing: false,
        isChecked: false
      };
      return {
        ...state,
        todos: [...state.todos, newTODO]
      };

    case ADD_TOKEN:
      return {
        ...state,
        token: [...state.token, action.payload]
      };

    case DELETE_TASK:
      return {
        ...state,
        todos: state.todos.filter((item, index) => index !== action.payload)
      };

    case EDIT_TASK:
      return {
        ...state,
        todos: state.todos.map((item, index) =>
          index === action.payload
            ? { ...item, isEditing: !item.isEditing }
            : item
        )
      };

    case COMPLETED_TASK:
      return {
        ...state,
        todos: state.todos.map((item, index) =>
          index === action.payload
            ? { ...item, isChecked: !item.isChecked }
            : item
        )
      };

    case SAVE_EDIT_TASK:
      return {
        ...state,
        todos: state.todos.map((item, index) =>
          index === action.payload.index
            ? {
                ...item,
                isEditing: !item.isEditing,
                description: action.payload.editValue
              }
            : item
        )
      };

    case GET_TODOS_BACK:
      console.log(action.payload);

      const newTodo = action.payload.filter(item => item);
      return {
        ...state,
        todos: [...state.todos, newTodo]
      };

    default:
      return state;
  }
};
