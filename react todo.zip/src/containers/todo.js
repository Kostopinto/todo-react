import { connect } from "react-redux";

import TodoApp from "../components/TodoApp";
import {
  addTask,
  deleteTask,
  editTask,
  completedTask,
  saveEditTask,
  login,
  loginUser,
  addToken,
  getAllTodos,
  getAll
} from "../actions/todo";

const mapStateToProps = state => ({
  todos: state.todo.todos,
  token: state.todo.token
});

const mapDispatchToProps = dispatch => {
  return {
    login: payload => dispatch(loginUser(payload)),
    addToken: payload => dispatch(addToken(payload)),
    addTask: payload => dispatch(addTask(payload)),
    deleteTask: payload => dispatch(deleteTask(payload)),
    getAllTodos: () => dispatch(getAll()),
    editTask,
    completedTask,
    saveEditTask
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TodoApp);
