module.exports = {
  jwt: {
    public: 'p',
    secret: 's',
  },
};
